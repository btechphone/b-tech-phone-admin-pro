# B-Tech Phone

B-Tech Phone commerce starter built with Next.js 15, TypeScript, Tailwind CSS, Supabase Auth/Postgres/Storage, and Vercel-ready environment variables.

## Admin features

- Professional responsive admin shell with active navigation.
- Product catalog CRUD and product media manager.
- Multi-image product upload to Supabase Storage bucket `btp-product-images`.
- Gallery read/delete, primary-image selection, and storefront gallery rendering.
- Inventory management.
- Order search by order number, customer, phone, courier, and tracking number.
- Order filters by status and date range.
- Shipping courier and tracking updates.
- Dashboard KPI for current-month paid revenue, paid orders, active catalog, customers, and pending payments.
- Sales report with date range, daily revenue trend, top products, transaction table, and CSV export.
- Existing payment verification flow remains protected by the admin authorization layer.

## Supabase

Required public environment variables:

```env
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
```

Never put a Supabase service-role/secret key in the browser or in a `NEXT_PUBLIC_*` variable.

Product images are stored in a public bucket so storefront visitors can load product media. Upload/update/delete operations are restricted to active admins by Storage RLS policies.

## Local development

```bash
npm install
npm run dev
```

For production, set the environment variables in Vercel and run the Supabase SQL migration included in `supabase/migrations/` against the B-Tech Phone project.
