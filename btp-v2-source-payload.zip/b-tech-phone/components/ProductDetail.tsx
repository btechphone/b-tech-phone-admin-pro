'use client'
import {useState} from 'react'
import {addToCart} from '@/lib/cart'
import {formatIDR} from '@/lib/catalog'
export function ProductDetail({product}:any){
 const [id,setId]=useState(product.variants[0]?.id);const [active,setActive]=useState(0)
 const v=product.variants.find((x:any)=>x.id===id);const stock=v?.inventory?Math.max(0,v.inventory.stock_quantity-v.inventory.reserved_quantity):0
 const images=[...(product.btp_product_images||[])].sort((a:any,b:any)=>a.sort_order-b.sort_order).map((x:any)=>({url:`${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/btp-product-images/${x.storage_path}`,alt:x.alt_text||product.name}))
 if(product.image_url&&!images.length)images.push({url:product.image_url,alt:product.name})
 return <div className="detail"><div><div className="detail-image product-gallery-main">{images[active]?<img src={images[active].url} alt={images[active].alt}/>:<span>📱</span>}</div>{images.length>1&&<div className="gallery-thumbs">{images.map((im:any,i:number)=><button type="button" key={im.url} className={i===active?'gallery-thumb active':'gallery-thumb'} onClick={()=>setActive(i)}><img src={im.url} alt=""/></button>)}</div>}</div><div><p className="eyebrow">{product.brand.name}</p><h1>{product.name}</h1><p>{product.short_description||product.description}</p><h3>Varian</h3><div className="variant-list">{product.variants.map((x:any)=><button type="button" key={x.id} className={x.id===id?'variant active':'variant'} onClick={()=>setId(x.id)}>{x.variant_name}<small>{formatIDR(Number(x.price))}</small></button>)}</div>{v&&<><p className="price">{formatIDR(Number(v.price))}</p><p>{stock>0?`Stok tersedia: ${stock}`:'Stok belum tersedia'}</p><button className="button" disabled={stock<1||Number(v.price)<=0} onClick={()=>addToCart({variantId:v.id,productId:product.id,productName:product.name,variantName:v.variant_name,sku:v.sku,price:Number(v.price),imageUrl:images[0]?.url||product.image_url,quantity:1})}>Tambah ke keranjang</button></>}</div></div>
}
