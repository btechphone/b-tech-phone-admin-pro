'use client'
import Link from 'next/link'
import {usePathname} from 'next/navigation'
import {BarChart3, Boxes, ClipboardList, CreditCard, Gauge, ImageIcon, Package, Settings, ShoppingBag, Users} from 'lucide-react'

const items = [
  {href:'/admin',label:'Overview',icon:Gauge},
  {href:'/admin/produk',label:'Produk & Media',icon:Package},
  {href:'/admin/stok',label:'Stok',icon:Boxes},
  {href:'/admin/order',label:'Order',icon:ShoppingBag},
  {href:'/admin/pembayaran',label:'Pembayaran',icon:CreditCard},
  {href:'/admin/pelanggan',label:'Customer',icon:Users},
  {href:'/admin/laporan',label:'Laporan Penjualan',icon:BarChart3},
  {href:'/admin/pengaturan',label:'Pengaturan',icon:Settings},
]
export default function AdminNav(){
  const pathname=usePathname()
  return <nav className="admin-nav">{items.map(({href,label,icon:Icon})=>{
    const active=href==='/admin'?pathname==='/admin':pathname.startsWith(href)
    return <Link className={active?'active':''} href={href} key={href}><Icon size={17}/><span>{label}</span></Link>
  })}</nav>
}
