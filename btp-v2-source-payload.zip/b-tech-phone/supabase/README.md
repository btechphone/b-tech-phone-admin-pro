# Supabase

Schema untuk project Btech sudah dibuat dan diverifikasi langsung pada project Supabase `hjxcytghofyvvgksvcdu`.
Migration lama yang memakai tabel `profiles` sengaja tidak disertakan agar tidak dijalankan terhadap schema B-Tech Phone yang sekarang.

Untuk perubahan database berikutnya, buat migration baru yang secara eksplisit memakai tabel `btp_*`.
