-- B-Tech Phone admin media + reporting indexes
create table if not exists public.btp_product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.btp_products(id) on delete cascade,
  storage_path text not null unique,
  alt_text text,
  sort_order integer not null default 0,
  is_primary boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists btp_product_images_product_sort_idx on public.btp_product_images(product_id, sort_order, created_at);
alter table public.btp_product_images enable row level security;
create policy btp_product_images_public_read on public.btp_product_images for select to anon, authenticated using (exists(select 1 from public.btp_products p where p.id=product_id and p.is_active=true));
create policy btp_product_images_admin_insert on public.btp_product_images for insert to authenticated with check ((select public.btp_is_admin()));
create policy btp_product_images_admin_update on public.btp_product_images for update to authenticated using ((select public.btp_is_admin())) with check ((select public.btp_is_admin()));
create policy btp_product_images_admin_delete on public.btp_product_images for delete to authenticated using ((select public.btp_is_admin()));
grant select on public.btp_product_images to anon, authenticated;
grant insert, update, delete on public.btp_product_images to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values ('btp-product-images','btp-product-images',true,10485760,array['image/jpeg','image/png','image/webp','image/avif']) on conflict(id) do update set public=true,file_size_limit=10485760,allowed_mime_types=array['image/jpeg','image/png','image/webp','image/avif'];
create policy btp_product_images_storage_admin_select on storage.objects for select to authenticated using(bucket_id='btp-product-images' and (select public.btp_is_admin()));
create policy btp_product_images_storage_admin_insert on storage.objects for insert to authenticated with check(bucket_id='btp-product-images' and (select public.btp_is_admin()));
create policy btp_product_images_storage_admin_update on storage.objects for update to authenticated using(bucket_id='btp-product-images' and (select public.btp_is_admin())) with check(bucket_id='btp-product-images' and (select public.btp_is_admin()));
create policy btp_product_images_storage_admin_delete on storage.objects for delete to authenticated using(bucket_id='btp-product-images' and (select public.btp_is_admin()));
create index if not exists btp_orders_status_created_idx on public.btp_orders(status,created_at desc);
create index if not exists btp_payments_status_created_idx on public.btp_payments(status,created_at desc);
create index if not exists btp_order_items_variant_id_idx on public.btp_order_items(variant_id);
create index if not exists btp_payments_verified_by_idx on public.btp_payments(verified_by);
