import './globals.css'; import Header from '@/components/Header';
export const metadata={title:'B-Tech Phone',description:'Katalog dan pemesanan smartphone B-Tech Phone'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body><Header/><main className="container">{children}</main></body></html>}
