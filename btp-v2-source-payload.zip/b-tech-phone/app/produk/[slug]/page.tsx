import {notFound} from 'next/navigation'
import {createClient} from '@/lib/supabase/server'
import {ProductDetail} from '@/components/ProductDetail'
export default async function Product({params}:{params:Promise<{slug:string}>}){const {slug}=await params;const s=await createClient();const {data}=await s.from('btp_products').select('id,name,slug,category,short_description,description,image_url,btp_product_images(id,storage_path,alt_text,sort_order,is_primary),brand:btp_brands!inner(id,name,slug),variants:btp_product_variants(id,sku,variant_name,color,storage,ram,price,compare_at_price,inventory:btp_inventory(stock_quantity,reserved_quantity))').eq('slug',slug).eq('is_active',true).eq('btp_brands.is_active',true).single();if(!data)notFound();return <ProductDetail product={data as any}/>} 
