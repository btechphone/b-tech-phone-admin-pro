import {NextResponse} from 'next/server'; import {createClient} from '@/lib/supabase/server';
export async function POST(req:Request){const s=await createClient();const {data}=await s.auth.getClaims();if(data?.claims)await s.auth.signOut();return NextResponse.redirect(new URL('/',req.url))}
