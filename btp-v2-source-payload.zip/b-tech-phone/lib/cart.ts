export type CartItem = { variantId:string; productId:string; productName:string; variantName:string; sku:string; price:number; imageUrl:string|null; quantity:number }
export const CART_KEY='btp-cart'
export const loadCart=():CartItem[]=>{if(typeof window==='undefined')return [];try{return JSON.parse(localStorage.getItem(CART_KEY)||'[]')}catch{return []}}
export const saveCart=(items:CartItem[])=>{localStorage.setItem(CART_KEY,JSON.stringify(items));window.dispatchEvent(new Event('btp-cart-change'))}
export const addToCart=(item:CartItem)=>{const items=loadCart();const i=items.findIndex(x=>x.variantId===item.variantId);if(i>=0)items[i].quantity+=item.quantity;else items.push(item);saveCart(items)}
export const cartCount=()=>loadCart().reduce((n,x)=>n+x.quantity,0)
