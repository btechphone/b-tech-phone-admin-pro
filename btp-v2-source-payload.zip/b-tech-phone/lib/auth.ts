import {createClient} from '@/lib/supabase/server'
export async function requireUser(){const supabase=await createClient();const {data,error}=await supabase.auth.getClaims();if(error||!data?.claims?.sub) return null;return {supabase,userId:data.claims.sub as string,email:(data.claims.email as string|undefined)||null}}
export async function requireAdmin(){const auth=await requireUser();if(!auth)return null;const {data}=await auth.supabase.from('btp_admins').select('id,full_name,is_active').eq('auth_user_id',auth.userId).eq('is_active',true).maybeSingle();return data?{...auth,admin:data}:null}
