export type Brand = { id: string; name: string; slug: string }
export type Product = {
  id: string; name: string; slug: string; category: string; short_description: string | null;
  description: string | null; image_url: string | null; is_featured: boolean;
  brand: Brand; variants: Variant[]
}
export type Variant = { id: string; sku: string; variant_name: string; color: string | null; storage: string | null; ram: string | null; price: number; compare_at_price: number | null; inventory: { stock_quantity: number; reserved_quantity: number } | null }
export const formatIDR = (price: number) => price > 0 ? new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(price) : 'Harga dikonfirmasi admin'
export const whatsappUrl = (phone: string, message: string) => `https://wa.me/${phone.replace(/\D/g,'')}?text=${encodeURIComponent(message)}`
